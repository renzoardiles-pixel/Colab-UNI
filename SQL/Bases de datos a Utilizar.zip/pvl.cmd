@echo off
cls
osql -S -E -n -i C:\db\pvl.sql
pause